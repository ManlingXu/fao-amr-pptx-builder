# Vietnam AMR research, veterinary stewardship and risk communication

This example assembles three original slides from two public presentations. The first two slides concern Vietnam. The last gives examples of risk communication. Both source presentations were published in 2019. This is a historical demonstration of source selection and slide assembly.

| Output slide | Original slide | Original presentation |
|---|---|---|
| 1 | 5 | [Antimicrobial resistance and antimicrobial use initiatives in agricultural food system in Vietnam](https://cgspace.cgiar.org/items/f8b9bbe5-22ec-4a2d-90e6-2599f1fdb0c5) |
| 2 | 9 | [Antimicrobial resistance and antimicrobial use initiatives in agricultural food system in Vietnam](https://cgspace.cgiar.org/items/f8b9bbe5-22ec-4a2d-90e6-2599f1fdb0c5) |
| 3 | 41 | [One Health and food safety research in developing countries](https://cgspace.cgiar.org/items/a8ecb669-c44e-44d4-bf0b-335aa50da5f4) |

## Credits

- Antimicrobial resistance and antimicrobial use initiatives in agricultural food system in Vietnam. Trang Le, Sinh Dang-Xuan, Son Dang, Tran Minh Phu, Pham Duc Phuc, Hung Nguyen-Viet. Published 2019-10-09. [Source](https://cgspace.cgiar.org/items/f8b9bbe5-22ec-4a2d-90e6-2599f1fdb0c5) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
- One Health and food safety research in developing countries. Hung Nguyen-Viet, Sinh Dang-Xuan, Chea, Rortana. Published 2019-08-12. [Source](https://cgspace.cgiar.org/items/a8ecb669-c44e-44d4-bf0b-335aa50da5f4) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Original slides were excerpted and rearranged. Credits on each slide remain with their original authors and image contributors. The adjoining JSON file identifies the source and original page number of every output slide.
